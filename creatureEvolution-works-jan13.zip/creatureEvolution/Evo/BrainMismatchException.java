
/**
 * Write a description of class BrainMismatchException here.
 *
 * @author Aaron Fink
 * @version January 5
 */
public class BrainMismatchException extends Exception {
    public BrainMismatchException(String message) {
        super(message);
    }
}
